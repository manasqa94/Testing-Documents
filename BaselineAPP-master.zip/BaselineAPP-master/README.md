# BaselineAPP
This is for MobileAutomation testing using Appium

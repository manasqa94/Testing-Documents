package com.OnMobile.POM;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

public class HomeAppPage {

Logger logger = Logger.getLogger(HomeAppPage.class.getName());

By songs_Name= By.name("Main Kaun Hoon");

}
